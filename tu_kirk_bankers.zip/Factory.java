import java.io.*;
import java.util.*;

public class Factory {
    public static void main(String[] args) throws java.io.IOException {

        String filename = "C:/Users/Kris Tu/IdeaProjects/socket/bankers algorithm/src/infile";

        int numOfResources = args.length;

        int[] resources= new int[numOfResources];
        for (int i = 0; i < numOfResources; i++) {
            resources[i] = Integer.parseInt(args[i + 1].trim());
        }

        Bank theBank = new BankImpl(resources);
        int[] maxDemand = new int[numOfResources];
        int[] allocated = new int[numOfResources];

        Thread[] workers = new Thread[Customer.COUNT];
        String line;
        try {
            BufferedReader inFile = new BufferedReader(new FileReader(filename));

            int threadNum = 0;
            int resourceNum = 0;

            for (int i = 0; i < Customer.COUNT; i++) {
                line = inFile.readLine();
                StringTokenizer tokens = new StringTokenizer(line, ",");

                while (tokens.hasMoreTokens()) {
                    int amt = Integer.parseInt(tokens.nextToken().trim());
                    maxDemand[resourceNum++] = amt;
                }
                workers[threadNum] = new Thread(new Customer(threadNum, maxDemand, theBank));
                theBank.addCustomer(threadNum, allocated, maxDemand);
                ++threadNum;
                resourceNum = 0;
            }
        }
        catch (FileNotFoundException fnfe) {
            throw new Error("Unable to find file " + filename);
        }
        catch (IOException ioe) {
            throw new Error("Error processing " + filename);
        }
        System.out.println("FACTORY: created threads");     // start the customers

        for (int i = 0; i < Customer.COUNT; i++) { workers[i].start(); }
        System.out.println("FACTORY: started threads");


        BufferedReader cl = new BufferedReader(new InputStreamReader(System.in));
        int[] requests = new int[numOfResources];
        String requestLine;

        while ( (requestLine = cl.readLine()) != null) {
            if (requestLine.equals(""))
                continue;

            if (requestLine.equals("*")) {
                theBank.getState();
            }
            else {
                StringTokenizer tokens = new StringTokenizer(requestLine);

                String trans = tokens.nextToken().trim();

                int custNum = Integer.parseInt(tokens.nextToken().trim());

                for (int i = 0; i < numOfResources; i++) {
                    resources[i] = Integer.parseInt(tokens.nextToken().trim());
                    System.out.println("*"+resources[i]+"*");
                }
                if (trans.equals("RQ")) {
                    if (theBank.requestResources(custNum,resources)) {
                        System.out.println("APPROVED");
                    }
                    else {
                        System.out.println("DENIED");
                    }
                }
                else if (trans.equals("RL")) {
                    theBank.releaseResources(custNum, resources);
                }
                else {
                    System.err.println("Must be either 'RQ' or 'RL'");
                }
            }
        }
    }
}