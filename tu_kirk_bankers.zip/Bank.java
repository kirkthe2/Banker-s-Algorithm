public interface Bank {
    public void addCustomer(int threadNum, int[] maxDemand, int[] allocated);

    public void getState();

    public boolean requestResources(int threadNum, int[] request);

    public void releaseResources(int threadNum, int[] release);
}
